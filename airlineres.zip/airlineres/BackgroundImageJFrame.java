import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;
import java.applet.*;
public class BackgroundImageJFrame extends JFrame implements ActionListener
{
JLabel l1;
JButton b1;

public void Baframe()
{

setTitle("Background Color for JFrame");
setSize(400,400);
setLocationRelativeTo(null);
setDefaultCloseOperation(EXIT_ON_CLOSE);
setVisible(true);


setLayout(new BorderLayout());
JLabel background=new JLabel(new ImageIcon
("flight.jpg"));
add(background);
background.setLayout(new FlowLayout());
l1=new JLabel("WIZARD APPLICATION");
b1=new JButton("START");
background.add(l1);
background.add(b1);
b1.addActionListener(this);
setSize(399,399);
setSize(400,400);
}
public static void main(String[] args)  {
    
    BackgroundImageJFrame bg=new BackgroundImageJFrame();
    bg.Baframe();

    
    
 }
 @Override
 public void actionPerformed(ActionEvent ae){
     new LoginDemo();
 }

}

class LoginDemo extends JFrame implements ActionListener {
    JPanel panel;
    JLabel user_label, password_label;
    JTextField userName_text;
    JPasswordField password_text;
    JButton submit, cancel;
    JPanel panel1;
    JLabel usernamel,regnuml,mobnuml,emaill,addressl ;
    JTextField usernametf,regnumtf,mobnumtf,emailtf,addresstf ;
    JButton ok;
    Frame frm;
    String str;
    Runtime rt;
    LoginDemo() {
       // Username Label
       user_label = new JLabel();
       user_label.setText("User Name :");
       userName_text = new JTextField();
       
       // Password Label
       password_label = new JLabel();
       password_label.setText("Password :");
       password_text = new JPasswordField();
 
       // Submit
       submit = new JButton("LOGIN");
       panel = new JPanel(null);
       user_label.setBounds(50,150,100,30);
       userName_text.setBounds(150,150,150,30);
       password_label.setBounds(50,220,100,30);
       password_text.setBounds(150,220,150,30);
       submit.setBounds(50,300,100,30);
       panel.add(user_label);
       panel.add(userName_text);
       panel.add(password_label);
       panel.add(password_text);
       panel.add(submit);
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       // Adding the listeners to components..
       submit.addActionListener(this);
       add(panel, BorderLayout.CENTER);
       setTitle("Login");
       setSize(1000,1000);
       setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
       String userName = userName_text.getText();
       String password = password_text.getText();
       if (userName.trim().equals("admin") && password.trim().equals("admin")) {
          new details();
       } else {
          System.out.print("usdhcb");
       }
    }
 public class details extends JFrame implements ActionListener
 {
    details()
    {
       panel.setVisible(false);
       usernamel= new JLabel();
       usernamel.setText("Name :");
       usernametf = new JTextField();
 
       regnuml= new JLabel();
       regnuml.setText("Register Number:");
       regnumtf = new JTextField();
 
       mobnuml= new JLabel();
       mobnuml.setText("Mobile Number :");
       mobnumtf = new JTextField();
 
       emaill= new JLabel();
       emaill.setText("Email id :");
       emailtf = new JTextField();
 
       addressl= new JLabel();
       addressl.setText("Address :");
       addresstf = new JTextField();
 
       // Submit
       ok = new JButton("Submit");
       panel1 = new JPanel(null);
       usernamel.setBounds(50,150,100,30);
       usernametf.setBounds(250,150,150,30);
 
       regnuml.setBounds(50,220,150,30);
       regnumtf.setBounds(250,220,150,30);
 
       mobnuml.setBounds(50,290,150,30);
       mobnumtf.setBounds(250,290,150,30);
 
       emaill.setBounds(50,360,100,30);
       emailtf.setBounds(250,360,150,30);
 
       addressl.setBounds(50,430,100,30);
       addresstf.setBounds(250,430,150,30);
 
       ok.setBounds(50,500,100,30);
       panel1.add(usernamel);
       panel1.add(usernametf);
       panel1.add(regnuml);
       panel1.add(regnumtf);
       panel1.add(mobnuml);
       panel1.add(mobnumtf);
       panel1.add(emaill);
       panel1.add(emailtf);
       panel1.add(addressl);
       panel1.add(addresstf);
       panel1.add(ok);
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
       ok.addActionListener(this);
       add(panel1, BorderLayout.CENTER);
       setTitle("Student details");
       setSize(1000,1000);
       setVisible(true);
       
     }
    @Override
    public void actionPerformed(ActionEvent ae) {
       new wizard();
    }
 }
 public class wizard extends JFrame implements ActionListener
 {
    wizard()
    {
           panel1.setVisible(false);
           frm=new Frame("WIZARD");
           MenuBar mnubar=new MenuBar();
           frm.setSize(1000,1000);
           frm.setVisible(true);
           frm.setMenuBar(mnubar);
           
           Menu mnufile=new Menu("File");
         
           MenuItem mnunpd,mnuscan,mnubr;
           mnufile.add(mnunpd=new MenuItem("NotePad"));
           mnufile.add(mnuscan=new MenuItem("Scanners and cameras"));
           mnufile.add(mnubr=new MenuItem("Browser"));
          // mnufile.add(mnuexit=new MenuItem("Exit"));
           mnubar.add(mnufile);
           Menu mnucolor=new Menu("Color");
           MenuItem mnured,mnugrn,mnublue,mnuyel,mnuwhite,mnublack;
           mnucolor.add(mnured=new MenuItem("Red"));
           mnucolor.add(mnugrn=new MenuItem("Green"));
           mnucolor.add(mnublue=new MenuItem("Blue"));
           mnucolor.add(mnuyel=new MenuItem("Yellow"));
           mnucolor.add(mnuwhite=new MenuItem("White"));
           mnucolor.add(mnublack=new MenuItem("Black"));
           mnubar.add(mnucolor);
           Menu mnumulti=new Menu("MultiMedia");
           MenuItem mnucdplyr;
           mnumulti.add(mnucdplyr=new MenuItem("CD Player"));
           mnubar.add(mnumulti);
           Menu mnuexi=new Menu("Exit");
           MenuItem mnuexit;
           mnuexi.add(mnuexit=new MenuItem("Exit"));
           mnubar.add(mnuexi);
 
           mnunpd.addActionListener(this);
           mnuscan.addActionListener(this);
           mnubr.addActionListener(this);
           //mnuexit.addActionListener(this);
           mnured.addActionListener(this);
           mnugrn.addActionListener(this);
           mnublue.addActionListener(this);
           mnuyel.addActionListener(this);
           mnuwhite.addActionListener(this);
           mnublack.addActionListener(this);
           mnucdplyr.addActionListener(this);
           mnuexit.addActionListener(this);
      }
   @Override
    public void actionPerformed(ActionEvent ae) 
    {
         String str;
     Runtime rt;
    
 
     str=ae.getActionCommand();
     rt=Runtime.getRuntime();
     try
     {
                        if(str.equalsIgnoreCase("Notepad"))
                        rt.exec("c:\\windows\\notepad.exe");
                        else if(str.equalsIgnoreCase("Scanners and Cameras"))
                        rt.exec("c:\\Program Files\\Windows Photo Viewer\\ImagingDevices.exe");
                        else if(str.equalsIgnoreCase("Browser"))
                        rt.exec("c:\\program files\\internet explorer\\iexplore.exe");
                        else if(str.equalsIgnoreCase("Red"))
                        frm.setBackground(Color.RED);
                        else if(str.equalsIgnoreCase("Yellow"))
                        frm.setBackground(Color.YELLOW);
                        else if(str.equalsIgnoreCase("Green"))
                        frm.setBackground(Color.GREEN);
                        else if(str.equalsIgnoreCase("Blue"))
                        frm.setBackground(Color.BLUE);
                        else if(str.equalsIgnoreCase("White"))
                        frm.setBackground(Color.WHITE);
                        else if(str.equalsIgnoreCase("Black"))
                        frm.setBackground(Color.BLACK);
                        else if(str.equalsIgnoreCase("CD Player"))
                        rt.exec("c:\\Program Files\\Windows Media Player\\wmplayer.exe");
                        else if(str.equalsIgnoreCase("Exit"))
                        System.exit(0);
   }
     catch(Exception e)
     {
                        System.out.println("Exception:" +e);
    }
  }
 }
 }
   