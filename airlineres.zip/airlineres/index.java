/* This project title is Airline Reservation System and by using awt and swing we're going to 
create an UI.  Finally we'll connect Database with this UI.      Starts on 27/10/2021  */

//importing packages
import javax.swing.*;
import javax.swing.text.StyledEditorKit.BoldAction;
import java.io.IOException;

import java.awt.*;
import java.awt.event.*;
import java.awt.BorderLayout;

import java.sql.*;

// @Module 1 --> First page of project

class welcome extends JFrame implements ActionListener
{
    JPanel panel;
    JLabel user_label, password_label,titLabel,imgJLabel,howLabel,sign,gifLabel,dev;
    JTextField userName_text;
    JTextArea how_text;
    JPasswordField password_text;
    JButton submit,signin;
    JPanel panel1;
    String str;
    public void sign() 
    {
        user_label = new JLabel();
        user_label.setText("Username ");
        user_label.setFont(new Font("Times New Roamn",Font.BOLD,17));
        userName_text = new JTextField();
       

        password_label = new JLabel();
        password_label.setText("Password ");
        password_label.setFont(new Font("Times new roamn",Font.BOLD,17));
        password_text = new JPasswordField();

        titLabel = new JLabel();
        titLabel.setText("AIRLINE RESERVATION SYSTEM");
        titLabel.setFont(new Font("Verdana", Font.BOLD, 23));

        imgJLabel = new JLabel(new ImageIcon("flight.jpg"));
        gifLabel = new JLabel(new ImageIcon("line1.gif"));

        howLabel = new JLabel();
        howLabel.setText("HOW IT WORKS");
        howLabel.setFont(new Font("Times new roman",Font.BOLD,15));

        how_text = new JTextArea();
        how_text.setText("Lorem Ipsum is simply dummy \ntext of the printing and typesetting \nindustry. Lorem Ipsum has \nbeen the industry's standard dummy \ntext ever since the 1500s, \nwhen an unknown printer took \na galley of type and scrambled \nit to make a type specimen book. \nIt has survived not only five \ncenturies, but also the leap into \nelectronic typesetting, remaining \nessentially unchanged." );
        how_text.setFont(new Font("Times new roman",Font.ITALIC, 15));

        sign = new JLabel();
        sign.setText("If you are new user for this application Please sign in");

        signin = new JButton();
        Color s = new Color(255,0,0);
        signin.setBackground(s);
        signin.setText("Sign in");

        submit = new JButton("LOGIN");
        Color e = new Color(32,178,170);
        submit.setBackground(e);

        dev = new JLabel();
        dev.setText("@Developed by RamSaran");

        panel = new JPanel(null);
        titLabel.setBounds(568,45,500,30);
        signin.setBounds(1380,50,100,30);
        imgJLabel.setBounds(590,1,400,400);
        gifLabel.setBounds(600,640,390,20);
        user_label.setBounds(620,400,100,30);
        userName_text.setBounds(820,400,150,30);
        password_label.setBounds(620,450,100,30);
        password_text.setBounds(820,450,150,30);
        submit.setBounds(750,530,100,30);
        sign.setBounds(650,580,300,30);
        howLabel.setBounds(60,20,140,100);
        how_text.setBounds(40,100,160,400);
        dev.setBounds(710,800,500,30);

        Color c = new Color(135,206,235);
        panel.setBackground(c);
        panel.add(titLabel);
        panel.add(user_label);
        panel.add(userName_text);
        panel.add(password_label);
        panel.add(password_text);
        panel.add(submit);
        panel.add(sign);
        panel.add(signin);
        panel.add(imgJLabel);
        panel.add(gifLabel);
        panel.add(howLabel);
        panel.add(how_text);
        panel.add(dev);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        submit.addActionListener(this);
        signin.addActionListener(this);
        add(panel, BorderLayout.CENTER);
        setTitle("AIRLINE RESERVATION SYSTEM");
        setSize(1000,1000);
        setVisible(true);
        setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent ae)
    {
        String str;
        str = ae.getActionCommand();
        if(str.equalsIgnoreCase("SIGN IN"))
            new signin();
        else if(str.equalsIgnoreCase("LOGIN"))
            new airline();
    }

}
// --> end of @Module1 <--

// @Module 2 --> sign in page of project

class signin extends JFrame implements ActionListener
{
    JPanel panel;
    JLabel user_label, password_label, repass_label,email_label,img_label,titLabel,dev,howLabel,gifLabel;
    JTextField userName_text,email_text;
    JTextArea how_text;
    JPasswordField password_text,repass_text;
    JButton submit;
    String username,email,password,repassword;

    signin()
    {
        titLabel = new JLabel();
        titLabel.setText("Sign In");
        titLabel.setFont(new Font("Verdana", Font.BOLD, 23));

        user_label = new JLabel();
        user_label.setText("Username");
        user_label.setFont(new Font("Times new roamn",Font.BOLD,17));
        userName_text = new JTextField();

        email_label = new JLabel();
        email_label.setText("Email");
        email_label.setFont(new Font("Times new roamn",Font.BOLD,17));
        email_text = new JTextField();
       
        password_label = new JLabel();
        password_label.setText("Password");
        password_label.setFont(new Font("Times new roamn",Font.BOLD,17));
        password_text = new JPasswordField();

        repass_label = new JLabel();
        repass_label.setText("Re-password");
        repass_label.setFont(new Font("Times new roamn",Font.BOLD,17));
        repass_text = new JPasswordField();
 
        submit = new JButton("SIGNIN");

        img_label = new JLabel(new ImageIcon("signin.png"));
        gifLabel = new JLabel(new ImageIcon("line1.gif"));

        dev = new JLabel();
        dev.setText("@Developed by RamSaran");

        howLabel = new JLabel();
        howLabel.setText("HOW IT WORKS");
        howLabel.setFont(new Font("Times new roman",Font.BOLD,15));

        how_text = new JTextArea();
        how_text.setText("Lorem Ipsum is simply dummy \ntext of the printing and typesetting \nindustry. Lorem Ipsum has \nbeen the industry's standard dummy \ntext ever since the 1500s, \nwhen an unknown printer took \na galley of type and scrambled \nit to make a type specimen book. \nIt has survived not only five \ncenturies, but also the leap into \nelectronic typesetting, remaining \nessentially unchanged." );
        how_text.setFont(new Font("Times new roman",Font.ITALIC, 15));

        panel = new JPanel(null);
        titLabel.setBounds(725,25,100,30);
        img_label.setBounds(640,35,270,270);
        user_label.setBounds(600,350,100,30);
        userName_text.setBounds(780,350,150,30);
        email_label.setBounds(600,400,100,30);
        email_text.setBounds(780,400,150,30);
        password_label.setBounds(600,450,100,30);
        password_text.setBounds(780,450,150,30);
        repass_label.setBounds(600,500,150,30);
        repass_text.setBounds(780,500,150,30);
        submit.setBounds(720,570,100,30);
        how_text.setBounds(40,100,160,400);
        howLabel.setBounds(60,20,140,100);
        dev.setBounds(710,800,500,30);
        gifLabel.setBounds(600,640,390,20);

        Color c = new Color(32,178,170);
        panel.setBackground(c);
        panel.add(titLabel);
        panel.add(img_label);
        panel.add(user_label);
        panel.add(userName_text);
        panel.add(email_label);
        panel.add(email_text);
        panel.add(password_label);
        panel.add(password_text);
        panel.add(repass_label);
        panel.add(repass_text);
        panel.add(submit);
        panel.add(dev);
        panel.add(how_text);
        panel.add(howLabel);
        panel.add(gifLabel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        submit.addActionListener(this);
        add(panel, BorderLayout.CENTER);

        setTitle("Sign in");
        setSize(1000,1000);
        setVisible(true);
        setLocationRelativeTo(null);
    }
    public void actionPerformed(ActionEvent ae)
    {
        String username = userName_text.getText();
        String password = password_text.getText();
        String email = email_text.getText();
        String repassword = repass_text.getText();

        try
        {
            System.out.println(username);  
            Class.forName("com.mysql.jdbc.Driver");  
            Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/airline","root","");
            Statement st=con.createStatement();
            st.executeUpdate("insert into signin values('"+username+"','"+email+"','"+password+"','"+repassword+"')");
        }
        catch(Exception e)
        {
            System.out.println("Not connected");
        }
        new airline();
    }
}
// --> end of @MOdule2 <--

// @Module3 --> Reservation form of project

class airline extends JFrame implements ActionListener
{
    JLabel titlabel,dev,resdetailLabel,resdateLabel,ticketLabel,ticketfairLabel,ticketfairLabel1,taxfairLabel,totalfairLabel,flightnameLabel,flightdateLabel,fclassLabel,PNRnoLabel,passdetailLabel,flightnoLabel,passnameLabel,passaddLabel,passportnoLabel,fromLabel,toLabel,clsLabel;
    JPanel panel;
    JTextField taxfairTextField,totalfairTextField,ticketfairTextField,resdateTextField,flightnameTextField,flightdatTextField,PNRnoTextField,flightnoTextField,passnameTextField,passaddTextField,passportnoTextField;
    JComboBox froComboBox,toComboBox,classComboBox;
    JButton pay,flight;
    String s1,s2,s3,str;

    airline()
    {
        titlabel = new JLabel();
        titlabel.setText("Airline Reservation Ticket");
        titlabel.setFont(new Font("Verdana", Font.BOLD, 23));

        resdetailLabel = new JLabel();
        resdetailLabel.setText("Reservation Details  :");
        resdetailLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        resdateLabel = new JLabel();
        resdateLabel.setText("Reservation Date");
        resdateLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        resdateTextField = new JTextField();

        flightdateLabel = new JLabel();
        flightdateLabel.setText("Flight date");
        flightdateLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        flightdatTextField = new JTextField();

        flightnameLabel = new JLabel();
        flightnameLabel.setText("Flight name");
        flightnameLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        flightnameTextField = new JTextField();

        fclassLabel = new JLabel();
        fclassLabel.setText("Class");
        fclassLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        flightnoLabel = new JLabel();
        flightnoLabel.setText("Flight No.");
        flightnoLabel.setFont(new Font("Times new roamn",Font.BOLD,17));
    
        flightnoTextField = new JTextField();

        PNRnoLabel = new JLabel();
        PNRnoLabel.setText("PNR No");
        PNRnoLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        PNRnoTextField = new JTextField();

        clsLabel = new JLabel();
        clsLabel.setText("Class");
        clsLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        String s3[] = {"First","Business","Economic"};
        classComboBox = new JComboBox(s3);

        ticketLabel = new JLabel();
        ticketLabel.setText("Ticket Price :");
        ticketLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        ticketfairLabel = new JLabel();
        ticketfairLabel.setText("Ticker Fair :");
        ticketfairLabel.setFont(new Font("Times new roamn",Font.BOLD,17));
        ticketfairTextField = new JTextField();

        taxfairLabel = new JLabel();
        taxfairLabel.setText("Tax Fair :");
        taxfairLabel.setFont(new Font("Times new roamn",Font.BOLD,17));
        taxfairTextField = new JTextField();

        totalfairLabel = new JLabel();
        totalfairLabel.setText("Total Fair :");
        totalfairLabel.setFont(new Font("Times new roamn",Font.BOLD,17));
        totalfairTextField = new JTextField();

        passnameLabel = new JLabel();
        passnameLabel.setText("Passenger name");
        passnameLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        passnameTextField = new JTextField();

        passdetailLabel = new JLabel();
        passdetailLabel.setText("Passengers Details  :");
        passdetailLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        passaddLabel = new JLabel();
        passaddLabel.setText("Address");
        passaddLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        passaddTextField = new JTextField();

        passportnoLabel = new JLabel();
        passportnoLabel.setText("Passport No.");
        passportnoLabel.setFont(new Font("Times new roamn",Font.BOLD,17));

        passportnoTextField = new JTextField();

        fromLabel = new JLabel();
        fromLabel.setText("From ");
        fromLabel.setFont(new Font("Times new roamn",Font.BOLD,17));
        String s1[] = {"Chennai"};
        froComboBox = new JComboBox(s1);


        toLabel = new JLabel();
        toLabel.setText("To ");
        toLabel.setFont(new Font("Times new roamn",Font.BOLD,17));
        String s2[] = {"Bangalore","Delhi","Mumbai"};
        toComboBox = new JComboBox(s2);

        pay = new JButton();
        pay.setText("Book");
        pay.setFont(new Font("Times new roamn",Font.BOLD,15));

        // flight = new JButton();
        // flight.setText("Check Flights"); 
        // flight.setFont(new Font("Times new roamn",Font.BOLD,15));

        dev = new JLabel();
        dev.setText("@Developed by RamSaran");

        titlabel.setBounds(650,25,400,30);
        resdetailLabel.setBounds(25,90,200,30);
        resdateLabel.setBounds(100,140,200,30);
        resdateTextField.setBounds(360,145,180,25);
        PNRnoLabel.setBounds(100,200,200,30);
        PNRnoTextField.setBounds(360,205,180,25);
        flightdateLabel.setBounds(100,260,200,30);
        flightdatTextField.setBounds(360,265,180,25);
        flightnoLabel.setBounds(100,320,200,30);
        flightnoTextField.setBounds(360,325,180,25);
        clsLabel.setBounds(100,380,200,30);
        classComboBox.setBounds(360,380,180,30);
        fromLabel.setBounds(1000,140,200,30);
        froComboBox.setBounds(1260,145,180,25);
        ticketLabel.setBounds(925,90,200,30);
        toLabel.setBounds(1000,200,200,30);
        toComboBox.setBounds(1260,205,180,25);
        ticketfairLabel.setBounds(1000,260,200,30);
        ticketfairTextField.setBounds(1260,265,180,25);
        taxfairLabel.setBounds(1000,320,200,30);
        taxfairTextField.setBounds(1260,325,180,25);
        totalfairLabel.setBounds(1000,380,200,30);
        totalfairTextField.setBounds(1260,385,180,25);
        passdetailLabel.setBounds(25,530,200,30);
        passnameLabel.setBounds(100,580,200,30);
        passnameTextField.setBounds(360,585,210,25);
        passaddLabel.setBounds(100,640,200,30);
        passaddTextField.setBounds(360,645,350,35);
        passportnoLabel.setBounds(100,710,200,30);
        passportnoTextField.setBounds(360,715,200,25);
        pay.setBounds(1170,465,170,40);
        dev.setBounds(710,800,500,30);  //600
        // flight.setBounds(1380,20,150,30);

        panel = new JPanel(null);
        Color c = new Color(221, 173, 117);
        panel.setBackground(c);
        panel.add(titlabel);
        panel.add(resdetailLabel);
        panel.add(resdateLabel);
        panel.add(resdateTextField);
        panel.add(PNRnoLabel);
        panel.add(PNRnoTextField);
        panel.add(flightdateLabel);
        panel.add(flightdatTextField);
        panel.add(flightnoLabel);
        panel.add(flightnoTextField);
        panel.add(ticketLabel);
        panel.add(fromLabel);
        panel.add(froComboBox);
        panel.add(clsLabel);
        panel.add(classComboBox);
        panel.add(toLabel);
        panel.add(toComboBox);
        panel.add(ticketfairLabel);
        panel.add(ticketfairTextField);
        panel.add(taxfairLabel);
        panel.add(taxfairTextField);
        panel.add(totalfairLabel);
        panel.add(totalfairTextField);
        panel.add(passdetailLabel);
        panel.add(passnameLabel);
        panel.add(passnameTextField);
        panel.add(passaddLabel);
        panel.add(passaddTextField);
        panel.add(passportnoLabel);
        panel.add(passportnoTextField);
        panel.add(pay);
        panel.add(dev);
        // panel.add(flight);

        pay.addActionListener(this);
        add(panel, BorderLayout.CENTER);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Airline Ticket Reservation");
        setSize(1000,1000);
        setVisible(true);
        setLocationRelativeTo(null);
    }
    public void actionPerformed(ActionEvent ae)
    {
        String reservation_date = resdateTextField.getText();
        String pnr_no = PNRnoTextField.getText();
        String flight_date = flightdatTextField.getText();
        String flight_no = flightnoTextField.getText();
        String passenger_name = passnameTextField.getText();
        String address = passaddTextField.getText();
        String passportno = passportnoTextField.getText();
        String ticketfair = ticketfairTextField.getText();
        String taxfair = taxfairTextField.getText();
        String totalfair = totalfairTextField.getText();
        try
        { 
            Class.forName("com.mysql.jdbc.Driver");  
            Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/airline","root","");
            Statement st=con.createStatement();
            st.executeUpdate("insert into ticket values('"+reservation_date+"','"+pnr_no+"','"+flight_date+"','"+flight_no+"','"+passenger_name+"','"+address+"','"+passportno+"','"+ticketfair+"','"+taxfair+"','"+totalfair+"')");
            
        }
        catch(Exception e)
        {
            System.out.println("Not connected");
        }
        new ticket();
    }
}
// --> end of @Module3 <--

class ticket extends JFrame
{
    JLabel imgLabel;
    ticket()
    {
        imgLabel = new JLabel(new ImageIcon("ticket.jpeg"));
        JPanel panel = new JPanel();

        panel.add(imgLabel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(panel, BorderLayout.CENTER);
        setTitle("TICKET");
        setSize(655,416);
        setVisible(true);
        setLocationRelativeTo(null);
    }
}
//Main class
public class index extends JFrame
{
    public static void main(String[] args) 
    {
        welcome i = new welcome();
        i.sign();
        System.out.println("hello");
    }
}

