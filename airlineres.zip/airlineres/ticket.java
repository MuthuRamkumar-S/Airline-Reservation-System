// import javax.swing.*;
// import java.awt.*;

// public class ticket extends JFrame
// {
//     JLabel imgLabel;
//     public void ticket1()
//     {
//         imgLabel = new JLabel(new ImageIcon("ticket.jpeg"));
//         JPanel panel = new JPanel();

//         panel.add(imgLabel);
//         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//         add(panel, BorderLayout.CENTER);
//         setTitle("TICKET");
//         setSize(655,416);
//         setVisible(true);
//         setLocationRelativeTo(null);
//     }
//     public static void main(String[] args) 
//     {
//         ticket i = new ticket();
//         i.ticket1();
//     }
// }
